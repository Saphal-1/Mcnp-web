# MCNP Staff Application

A professional, responsive MCNP staff application split into HTML, CSS and JavaScript, with a server-side Discord webhook endpoint.

## Files

- `index.html` — application structure
- `styles.css` — responsive glass/gradient UI
- `script.js` — validation, progress, upload UI and submission
- `server.js` — secure webhook relay
- `package.json` — Node dependencies

Keep your existing `logo.png` beside `index.html`.

## Discord webhook setup

1. Install Node.js 18+.
2. Run `npm install`.
3. Set an environment variable:

`DISCORD_WEBHOOK_URL=YOUR_DISCORD_WEBHOOK_URL`

4. Start with:

`npm start`

5. Open the site through the Node server, not by opening `index.html` directly.

## Important privacy/security note

The browser must never contain the Discord webhook URL. The server relays the application to Discord.

The optional verification document is accepted by the backend in memory but is NOT sent to Discord. If your management workflow needs document review, add secure private storage with strict access controls and a documented retention/deletion policy. Avoid collecting unnecessary identity information.
